﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
	public GameObject MainMenuUI, OptionsMenuUI;

	void Start()
	{

	}

	public void PlayGame()
	{
		//SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
		SceneManager.LoadScene("Main");
	}

	public void OpenOptionsMenu()
	{
		OptionsMenuUI.SetActive(true);
		MainMenuUI.SetActive(false);
	}

	public void ReturnToMainMenu()
	{
		OptionsMenuUI.SetActive(false);
		MainMenuUI.SetActive(true);
	}

	public void GameToMenu()
	{
		SceneManager.LoadScene("Menu");
	}

	public void QuitGame()
	{
#if UNITY_EDITOR
		UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
	}
}
